<?php

$host = "prodinstance.cvdlzosnywn6.us-east-1.rds.amazonaws.com"; // Replace with your RDS endpoint

$dbname = "proddb";

$username = "admin";

$password = "Admin54132";

 

try {

    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {

    die("Database connection failed: " . $e->getMessage());

}

 

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $input_username = $_POST["username"];

    $input_password = $_POST["password"];

 

    // Check if the username already exists in the database

    $query = "SELECT * FROM users WHERE username = :username";

    $stmt = $pdo->prepare($query);

    $stmt->bindParam(":username", $input_username);

    $stmt->execute();

 

    if ($stmt->rowCount() > 0) {

        echo "Username already exists. Please choose a different username.";

    } else {

        // Insert the new user into the database

        $query = "INSERT INTO users (username, password) VALUES (:username, :password)";

        $stmt = $pdo->prepare($query);

        $stmt->bindParam(":username", $input_username);

        $stmt->bindParam(":password", $input_password); // NOTE: In a real application, you should hash the password before storing it.

        $stmt->execute();

 

        echo "Registration successful!";

    }

}

?>